#!/usr/bin/perl -w
#
# see http://search.cpan.org/~atrak/NetPacket-0.04/
#
# firstly you need to add a iptables rule to make packets reach to NFQUEUE

use strict;

BEGIN {
	push @INC,"perl";
	push @INC,"build/perl";
	push @INC,"NetPacket-0.04";
};

use nfqueue;

use NetPacket::IP qw(IP_PROTO_TCP);
use NetPacket::TCP;
use Socket qw(AF_INET AF_INET6);

my $q;

sub cleanup()
{
	print "unbind\n";
	$q->unbind(AF_INET);
	print "close\n";
	$q->close();
}

sub my_cb()
{
	my ($dummy,$payload) = @_;
	print "Perl callback called!\n";
	print "dummy is $dummy\n" if $dummy;
	if ($payload) {
		print "len: " . $payload->get_length() . "\n";
		
		# get hardware addrss
		my $mac = $payload->get_packet_hw();
		$mac =~ s/(..)/$1:/g;
		$mac =~ s/:$//;
		print "mac: " . $mac . "\n";
	
		# get bindings version
		my $version = &nfqueue::nfq_bindings_version();
		if ($version){
			print "bindings version: " . $version . "\n";
		}else{
			print "get bindings version failed\n";
		}

		my $ip_obj = NetPacket::IP->decode($payload->get_data());
		print $ip_obj, "\n";
		print("$ip_obj->{src_ip} => $ip_obj->{dest_ip} $ip_obj->{proto}\n");
		print "Id: " . $payload->swig_id_get() . "\n";

		if($ip_obj->{proto} == IP_PROTO_TCP) {
			# decode the TCP header
			my $tcp_obj = NetPacket::TCP->decode($ip_obj->{data});

			print "TCP src_port: $tcp_obj->{src_port}\n";
			print "TCP dst_port: $tcp_obj->{dest_port}\n";
		}

		$payload->set_verdict($nfqueue::NF_DROP);
	}
}


$q = new nfqueue::queue();

$SIG{INT} = "cleanup";

$q->set_callback(\&my_cb);

$q->fast_open(0,AF_INET);

=cc
print "open\n";
$q->open();
print "bind\n";
$q->bind(AF_INET);

$SIG{INT} = "cleanup";

# print "set callback, wrong argument type (should fail)\n";
# but cannot capture the error!
#my @var = (3);
#$q->set_callback(\@var);
#print $!, $@, $^E, $?;		# null

print "setting callback\n";
$q->set_callback(\&my_cb);

print "creating queue\n";
$q->create_queue(0);
=cut

$q->set_queue_maxlen(5000);

print "trying to run\n";
$q->try_run();


