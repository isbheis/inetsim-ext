
void throw_exception(char *msg);

void clear_exception();

char *check_exception();

