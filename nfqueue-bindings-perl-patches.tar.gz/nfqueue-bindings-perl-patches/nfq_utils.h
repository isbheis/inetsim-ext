#ifndef __NFQ_UTILS__
#define __NFQ_UTILS__

int timeval_subtract (struct timeval *result, struct timeval *x, struct timeval *y);

#endif /* __NFQ_UTILS__ */
